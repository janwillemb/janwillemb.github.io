package com.example.foodapp;

import java.util.List;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;

public interface FoodApi {
    @GET("/menukaart")
    public void getMenukaart(@Query("id") int id, Callback<List<Menukaart>> callback);
}
