package com.example.foodapp;

import retrofit.RestAdapter;

public class FoodApiFactory {

    public FoodApi createClient() {
        // 10.0.2.2 = de PC waarop de Android emulator gehost wordt
        // hier moet je natuurlijk je eigen host invullen.
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint("http://10.0.2.2:3000")
                .build();

        return adapter.create(FoodApi.class);
    }
}
