package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.List;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // dit is niet de plek waar dit moet, maar om te
        this.testApi();
    }

    private void testApi() {
        FoodApi api = new FoodApiFactory().createClient();
        api.getMenukaart(3, new Callback<List<Menukaart>>() {
            @Override
            public void success(List<Menukaart> menukaarten, Response response) {
                if (menukaarten.size() > 0) {
                    String name = menukaarten.get(0).getName();
                    System.out.println("Menukaart: " + name);
                } else {
                    System.out.println("niets gevonden");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                System.out.println("Er is iets foutgegaan: " + error.getMessage());
            }
        });
    }
}