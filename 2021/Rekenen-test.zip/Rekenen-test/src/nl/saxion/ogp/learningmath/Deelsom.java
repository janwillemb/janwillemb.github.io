package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

public class Deelsom extends Rekensom{

    public Deelsom() {
        int getal1;
        int getal2;
        do {
            getal1 = SaxionApp.getRandomValueBetween(1, 100);
            getal2 = SaxionApp.getRandomValueBetween(2, 10);
        } while (getal1 % getal2 > 0);

        this.getal1 = getal1;
        this.getal2 = getal2;
    }

    @Override
    public String toonRekensom() {
        return "Deel " + getal1 + " door " + getal2;
    }

    @Override
    protected int berekenUitkomst() {
        return getal1 / getal2;
    }
}
