package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

public class Keersom extends Rekensom {
    @Override
    public String toonRekensom() {
        return "Wat is " + getal1 + " keer " + getal2 + "?";
    }

    @Override
    protected int berekenUitkomst() {
        return getal1 * getal2;
    }
}
