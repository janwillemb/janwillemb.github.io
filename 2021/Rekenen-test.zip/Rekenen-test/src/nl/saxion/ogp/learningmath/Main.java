package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

import java.awt.*;
import java.util.ArrayList;

public class Main implements Runnable {

    public static void main(String[] args) {
        SaxionApp.start(new Main());
    }

    @Override
    public void run() {

        ArrayList<Rekensom> sommen = new ArrayList<>();

        sommen.add(new Optelsom());
        sommen.add(new Keersom());
        sommen.add(new Deelsom());

        for (Rekensom som : sommen) {
            String tekst = som.toonRekensom();
            SaxionApp.printLine(tekst);
            SaxionApp.print("> ", Color.RED);

            int invoer = SaxionApp.readInt();

            if (som.controleerInvoer(invoer)) {
                SaxionApp.printLine("Goed zo");
            } else {
                SaxionApp.printLine("grrr");
            }

        }

    }
}
