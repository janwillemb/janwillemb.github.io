package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

public class Optelsom extends Rekensom {

    @Override
    public String toonRekensom() {
        return "Tel de volgende getallen bij elkaar op: " + getal1 + " en " + getal2;
    }

    @Override
    protected int berekenUitkomst() {
        return getal1 + getal2;
    }
}
