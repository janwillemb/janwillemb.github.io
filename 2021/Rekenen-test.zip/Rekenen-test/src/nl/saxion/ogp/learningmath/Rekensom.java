package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

public class Rekensom {

    protected int getal1;
    protected int getal2;
    protected int invoer;

    public Rekensom() {
        this.getal1 = SaxionApp.getRandomValueBetween(1, 20);
        this.getal2 = SaxionApp.getRandomValueBetween(1, 10);
    }

    public String toonRekensom() {
        return "Doe iets met de volgende getallen: " + getal1 + " en " + getal2;
    }

    protected int berekenUitkomst() {
        throw new RuntimeException("not implemented");
    }

    public boolean controleerInvoer(int invoer) {
        int uitkomst = berekenUitkomst();
        return invoer == uitkomst;
    }

    public int getGetal1() {
        return getal1;
    }

    public int getGetal2() {
        return getal2;
    }
}
