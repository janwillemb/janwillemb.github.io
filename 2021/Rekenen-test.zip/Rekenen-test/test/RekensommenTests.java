import nl.saxion.ogp.learningmath.Deelsom;
import nl.saxion.ogp.learningmath.Optelsom;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class RekensommenTests {

    @Test
    public void DeelsomKiestTweeGetallenZonderRest() {
        // Arrange
        Deelsom som;

        for (int i = 0; i < 1000; i++) {
            // Act
            som = new Deelsom();

            // Assert
            int getal1 = som.getGetal1();
            int getal2 = som.getGetal2();

            int rest = getal1 % getal2;

            Assertions.assertEquals(0, rest);
        }
    }

    @Test
    public void DeelsomBerekenUitkomstWerktCorrect() {
        // arrange

        // act

        // assert

    }

}
