package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

public class Deelsom extends Rekensom{

    @Override
    public void toonRekensom() {
        SaxionApp.printLine("Deel " + getal1 + " door " + getal2);
    }
}
