package nl.saxion.ogp.learningmath;

import nl.saxion.app.*;

public class Main implements Runnable {

    public static void main(String[] args) {
        SaxionApp.start(new Main());
    }

    @Override
    public void run() {

        Optelsom som = new Optelsom();
        som.toonRekensom();
        som.vraagInvoer();
        som.controleer();

        Keersom keersom = new Keersom();
        keersom.toonRekensom();
        keersom.vraagInvoer();
        keersom.controleer();

        Deelsom deelsom = new Deelsom();
        deelsom.toonRekensom();
        deelsom.vraagInvoer();
        deelsom.controleer();

    }
}
