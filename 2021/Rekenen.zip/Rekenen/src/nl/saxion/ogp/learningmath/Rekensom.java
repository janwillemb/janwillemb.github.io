package nl.saxion.ogp.learningmath;

import nl.saxion.app.SaxionApp;

import java.awt.*;

public class Rekensom {

    protected int getal1;
    protected int getal2;
    protected int invoer;

    public Rekensom() {
        getal1 = SaxionApp.getRandomValueBetween(0, 20);
        getal2 = SaxionApp.getRandomValueBetween(0, 10);
    }

    public void toonRekensom() {
        SaxionApp.printLine("Doe iets met de volgende getallen: " + getal1 + " en " + getal2);
    }

    public void vraagInvoer() {
        SaxionApp.print("> ", Color.RED);
        invoer = SaxionApp.readInt();
    }

    protected int berekenUitkomst() {
        throw new RuntimeException("not implemented");
    }

    public void controleer() {
        int uitkomst = berekenUitkomst();
        if (invoer == uitkomst) {
            SaxionApp.printLine("Goed zo");
        } else {
            SaxionApp.printLine("grrr");
        }
    }


}
